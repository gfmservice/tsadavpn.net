#!/bin/bash
tm="$(date +%s)"
dt="$(date +'%Y-%m-%d %H:%M:%S')"
timestamp="$(date +'%FT%TZ')"

DB_HOST='HOSTXX'
DB_USER='USERXX'
DB_PASS='PASSXX'
DB_NAME='DBXX'

username=`head -n1 $1 | tail -1`   
password=`head -n2 $1 | tail -1`

##Authentication
PRIVATE="user_name='$username' AND auth_vpn=md5('$password') AND is_freeze=1 AND is_active=1 AND is_ban=1 AND is_suspend=1 AND private_duration > 0 "
PRE="user_name='$username' AND auth_vpn=md5('$password') AND is_freeze=1 AND is_active=1 AND is_ban=1 AND is_suspend=1 AND duration > 0 "
VIP="user_name='$username' AND auth_vpn=md5('$password') AND is_freeze=1 AND is_active=1 AND is_ban=1 AND is_suspend=1 AND vip_duration > 0 "
Query="SELECT user_name FROM user WHERE $PRE OR $VIP OR $PRIVATE"
user_id=`mysql -u $DB_NAME -p$DB_PASS -D $DB_NAME -h $DB_HOST -sN -e "$Query"`
if [ "$user_id" == "$username" ]; then
	echo "user : $username"
	echo "authentication ok."
	exit 0
else
	echo "authentication failed."
	exit 1
fi
