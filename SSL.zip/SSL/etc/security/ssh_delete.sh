#!/bin/bash
site="xxx"
wget -q "$site/api/ssh/delete.txt" -O /root/delete.txt
IFS=$'\n'
lst1="$(cat "/root/delete.txt" | base64 --decode )"  
for x in $lst1
do
	a1=$(echo $x | awk '{print $1}')
	/usr/sbin/userdel $a1
done
