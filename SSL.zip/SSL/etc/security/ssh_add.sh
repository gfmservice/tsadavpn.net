#!/bin/bash
site="xxx"
wget -q "$site/api/ssh/add.txt" -O /root/add.txt
IFS=$'\n'
lst1="$(cat "/root/add.txt" | base64 --decode )"
for i in $lst1
do
	username=$(echo $i | awk '{print $1}')
	password=$(echo $i | awk '{print $2}')
	id -u $username &>/dev/null || /usr/sbin/useradd -M -s /bin/bash "$username"
	echo $username:$password | /usr/sbin/chpasswd
	echo $username:$password
done
